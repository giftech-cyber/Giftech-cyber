import bear from "./bear.png";
import predatorcoin from "./predatorcoin.jpeg";
import highVoltage from "./high-voltage.png";
import predatorcoin from "./predatorcoin.jpeg";
import rocket from "./rocket.png";
import trophy from "./trophy.png";

export {
    bear,
    predatorcoin,
    highVoltage,
    predatorcoinhttps,
    rocket,
    trophy
}
